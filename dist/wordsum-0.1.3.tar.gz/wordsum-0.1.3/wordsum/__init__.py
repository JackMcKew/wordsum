__version__ = '0.1.3'

from wordsum.word_sum import count_words
from wordsum.word_sum import list_supported_formats
from wordsum.word_sum import count_files